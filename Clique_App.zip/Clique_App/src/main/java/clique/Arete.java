package clique;

public class Arete {
    public Sommet s1, s2;

    public Arete(Sommet s1, Sommet s2) {
        this.s1 = s1;
        this.s2 = s2;
    }

}
